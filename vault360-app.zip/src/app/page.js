export default function Home() {
  return (
    <div>
      <h2>Vault360</h2>
      <p><a href="/login">Go to login</a></p>
    </div>
  );
}
